#include "common/platform.h"

#include <algorithm>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <string>

#if defined(__linux__)
#include <pthread.h>
#include <sched.h>
#include <unistd.h>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>
#include <vector>
#endif

#include "common/log.h"
#include "runtime/runtime.h"

namespace dsr::platform {
namespace {
std::atomic<CreateUserFileFn> g_create{nullptr};
}
// The cores to keep busy threads on (all but the slowest kind), computed once. count 0: one kind of core.
namespace {
#if defined(__ANDROID__)
struct FastCores {
    cpu_set_t set;
    int count = 0;
    std::string list;
};
const FastCores& GetFastCores() {
    static FastCores fc;
    static std::once_flag once;
    std::call_once(once, [] {
        long khz[32] = {}, lowest = 0, highest = 0;
        for (int cpu = 0; cpu < 32; cpu++) {
            char path[96];
            snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", cpu);
            if (FILE* f = fopen(path, "r")) {
                if (fscanf(f, "%ld", &khz[cpu]) != 1) khz[cpu] = 0;
                fclose(f);
            }
            if (khz[cpu] > 0 && (!lowest || khz[cpu] < lowest)) lowest = khz[cpu];
            if (khz[cpu] > highest) highest = khz[cpu];
        }
        CPU_ZERO(&fc.set);
        if (!lowest || lowest == highest) return;  // one kind of core: nothing to avoid
        for (int cpu = 0; cpu < 32; cpu++)
            if (khz[cpu] > lowest) {
                CPU_SET(cpu, &fc.set);
                fc.list += " " + std::to_string(cpu);
                fc.count++;
            }
    });
    return fc;
}
// Android moves an app's threads between cpusets as it changes state (start-up, dialogs, focus), and on older
// kernels (4.x: Snapdragon 845) that resets their CPU affinity: the busy threads ended up on the efficiency
// cores for the whole session. A watchdog thread checks the registered threads every second and restores it.
struct Watched {
    pid_t tid;
    std::string who;
    int restores = 0;
    // Back-off: the next check, and the wait after a restore the system undid at once or refused (see WatchAffinity).
    std::chrono::steady_clock::time_point next_check{}, last_restore{}, calm_since{};
    int backoff_ms = 0;
};
std::mutex g_watch_mutex;
std::vector<Watched> g_watched;
// The cpuset a thread is in and that cpuset's CPUs, e.g. "/top-app (0-7)" (diagnostics).
std::string CpusetOf(pid_t tid) {
    char path[96], name[128] = {}, cpus[64] = {};
    snprintf(path, sizeof(path), "/proc/self/task/%d/cpuset", int(tid));
    if (FILE* f = fopen(path, "r")) {
        if (!fgets(name, sizeof(name), f)) name[0] = 0;
        fclose(f);
    }
    name[strcspn(name, "\n")] = 0;
    snprintf(path, sizeof(path), "/dev/cpuset%s/cpus", name);
    if (FILE* f = fopen(path, "r")) {
        if (!fgets(cpus, sizeof(cpus), f)) cpus[0] = 0;
        fclose(f);
    }
    cpus[strcspn(cpus, "\n")] = 0;
    return std::string(name[0] ? name : "?") + " (" + (cpus[0] ? cpus : "?") + ")";
}
// Online CPUs and their current clocks, e.g. "0:1766 1:1766 2:- 3:- 4:2803 ..." (MHz; "-" = offline). Phones
// take cores offline when hot (thermal) or idle: the affinity resets on the 6T came with that.
std::string CpuState() {
    std::string out;
    for (int cpu = 0; cpu < 16; cpu++) {
        char path[96];
        snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d/online", cpu);
        int online = 1;
        if (FILE* f = fopen(path, "r")) {
            if (fscanf(f, "%d", &online) != 1) online = 1;
            fclose(f);
        } else if (cpu > 0) {
            snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d", cpu);
            if (FILE* d = fopen(path, "r")) fclose(d);
            else break;  // no such CPU
        }
        long khz = 0;
        snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d/cpufreq/scaling_cur_freq", cpu);
        if (online)
            if (FILE* f = fopen(path, "r")) {
                if (fscanf(f, "%ld", &khz) != 1) khz = 0;
                fclose(f);
            }
        char item[32];
        if (!online) snprintf(item, sizeof(item), "%d:off ", cpu);
        else if (khz) snprintf(item, sizeof(item), "%d:%ld ", cpu, khz / 1000);
        else snprintf(item, sizeof(item), "%d:on ", cpu);
        out += item;
    }
    return out;
}
// First line of a small text file ("" if unreadable).
std::string ReadLine(const char* path) {
    char buf[256] = {};
    if (FILE* f = fopen(path, "r")) {
        if (!fgets(buf, sizeof(buf), f)) buf[0] = 0;
        fclose(f);
    }
    buf[strcspn(buf, "\n")] = 0;
    return buf;
}
// Why a thread may not use the performance cores: its cpuset, the CPUs the kernel allows it (Cpus_allowed_list)
// and the CPUs isolated by the Qualcomm core control (where the kernel shows them).
std::string WhyRefused(pid_t tid) {
    char path[96];
    snprintf(path, sizeof(path), "/proc/self/task/%d/status", int(tid));
    std::string allowed = "?";
    if (FILE* f = fopen(path, "r")) {
        char line[256];
        while (fgets(line, sizeof(line), f))
            if (!strncmp(line, "Cpus_allowed_list:", 18)) {
                line[strcspn(line, "\n")] = 0;
                const char* v = line + 18;
                while (*v == ' ' || *v == '\t') v++;
                allowed = v;
                break;
            }
        fclose(f);
    }
    std::string isolated = ReadLine("/sys/devices/system/cpu/isolated");
    std::string ctl;
    for (int cpu : {4, 6, 7}) {
        snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d/core_ctl/active_cpus", cpu);
        std::string a = ReadLine(path);
        if (!a.empty()) {
            ctl = " | core control: " + a + " active of the cluster at CPU " + std::to_string(cpu);
            break;
        }
    }
    return "cpuset " + CpusetOf(tid) + ", allowed CPUs " + allowed + ", isolated " +
           (isolated.empty() ? std::string("?") : isolated) + ctl;
}
void WatchAffinity() {
    pthread_setname_np(pthread_self(), "dsr-affinity");
    const FastCores& fc = GetFastCores();
    // Checked 10 times a second: on the OnePlus 6T the system reset the affinity about once a second, so with
    // a one-second check the threads still spent much of their time on the efficiency cores.
    // Back-off: some phones fight back. The 6T (Android 11) undid the restore again within a second, hundreds of times
    // per 10 s, and more and more often refused it (the performance cores taken away from the app: thermal / core
    // control), its threads moving every time. A thread whose restore was refused, or undone within a second, is
    // left where the system put it for a while: 200 ms, doubling up to 5 s each time it happens again; after 10 s
    // without a fight it is watched every 100 ms again.
    constexpr int kMinBackoffMs = 200, kMaxBackoffMs = 5000;
    using clock = std::chrono::steady_clock;
    int restored = 0, refused = 0, backoffs = 0;
    std::string why;
    bool why_logged = false;
    auto summary_at = clock::now() + std::chrono::seconds(10);
    for (;;) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        WaitWhilePaused();  // in the background the system moves threads as it likes: nothing to restore
        std::lock_guard<std::mutex> lk(g_watch_mutex);
        const auto now = clock::now();
        pid_t refused_tid = 0;
        for (size_t i = 0; i < g_watched.size();) {
            Watched& w = g_watched[i];
            cpu_set_t cur;
            CPU_ZERO(&cur);
            if (sched_getaffinity(w.tid, sizeof(cur), &cur) != 0) {  // thread gone
                g_watched.erase(g_watched.begin() + long(i));
                continue;
            }
            i++;
            if (now < w.next_check) continue;
            if (CPU_EQUAL(&cur, &fc.set)) {
                if (w.backoff_ms && now - w.calm_since > std::chrono::seconds(10)) w.backoff_ms = 0;
                continue;
            }
            // Undone within a second of our last restore: the system is fighting it.
            const bool fight = w.last_restore != clock::time_point{} && now - w.last_restore < std::chrono::seconds(1);
            const int r = sched_setaffinity(w.tid, sizeof(fc.set), &fc.set);
            (r == 0 ? restored : refused)++;
            if (r != 0 && !refused_tid) refused_tid = w.tid;
            if (++w.restores <= 2)
                LOGI("platform", "%s (tid %d): CPU affinity reset by the system (%d CPUs allowed, cpuset %s), "
                     "restored to CPUs%s: %s", w.who.c_str(), int(w.tid), CPU_COUNT(&cur), CpusetOf(w.tid).c_str(),
                     fc.list.c_str(), r == 0 ? "ok" : "refused");
            if (r == 0) w.last_restore = now;
            if (r != 0 || fight) {
                w.backoff_ms = w.backoff_ms ? std::min(w.backoff_ms * 2, kMaxBackoffMs) : kMinBackoffMs;
                w.next_check = now + std::chrono::milliseconds(w.backoff_ms);
                w.calm_since = w.next_check;
                backoffs++;
            }
        }
        if (refused_tid && !why_logged) why = WhyRefused(refused_tid), why_logged = true;
        if (now >= summary_at) {
            summary_at += std::chrono::seconds(10);
            if (restored || refused) {
                int longest = 0;
                for (const Watched& w : g_watched) longest = std::max(longest, w.backoff_ms);
                LOGI("platform", "CPU affinity of the busy threads reset by the system and restored %d times in the "
                     "last 10 s (%d refused: none of CPUs%s online/allowed; %d back-offs, longest now %d ms); CPUs now: %s",
                     restored, refused, fc.list.c_str(), backoffs, longest, CpuState().c_str());
            }
            if (refused && !why.empty()) LOGI("platform", "refused: %s", why.c_str());
            restored = refused = backoffs = 0;
            why.clear();
            why_logged = false;
        }
    }
}
#endif
}  // namespace

namespace {
#if defined(__ANDROID__)
// Below this many fast cores, only the game's main thread is pinned. On a Helio G80 (2 fast + 6 slow) eight busy
// threads were kept on CPUs 6-7 with the pipeline compilers inheriting the same two cores while six cores idled:
// pipelines took seconds to build and objects went undrawn meanwhile (issue #27). The scheduler places the rest.
constexpr int kFewFastCores = 4;
bool FewFastCores() {
    if (!dsr::GetRuntime().config.fast_cores) return false;
    const FastCores& fc = GetFastCores();
    return fc.count > 0 && fc.count < kFewFastCores;
}
int SetAllCores() {
    cpu_set_t all;
    CPU_ZERO(&all);
    const long n = sysconf(_SC_NPROCESSORS_CONF);
    for (long c = 0; c < n && c < CPU_SETSIZE; c++) CPU_SET(c, &all);
    return sched_setaffinity(0, sizeof(all), &all);
}
#endif
}  // namespace

void UseAllCores() {
#if defined(__ANDROID__)
    SetAllCores();  // best effort
#endif
}

void ReleaseInheritedPin() {
#if defined(__ANDROID__)
    if (FewFastCores()) SetAllCores();
#endif
}

void PreferFastCores(const char* who, bool essential) {
#if defined(__ANDROID__)
    thread_local bool done = false;
    if (done) return;
    done = true;
    if (!dsr::GetRuntime().config.fast_cores) return;
    const FastCores& fc = GetFastCores();
    if (fc.count <= 0) return;
    if (!essential && fc.count < kFewFastCores) {
        const int r = SetAllCores();  // it may have inherited the main thread's pin
        LOGI("platform", "%s left to the scheduler on all CPUs (only %d fast cores:%s): %s", who, fc.count,
             fc.list.c_str(), r == 0 ? "ok" : "refused");
        return;
    }
    const int r = sched_setaffinity(0, sizeof(fc.set), &fc.set);
    LOGI("platform", "%s kept on CPUs%s: %s", who, fc.list.c_str(), r == 0 ? "ok" : "refused");
    {
        std::lock_guard<std::mutex> lk(g_watch_mutex);
        g_watched.push_back({pid_t(gettid()), who});
    }
    static std::once_flag watch_once;
    std::call_once(watch_once, [] { std::thread(WatchAffinity).detach(); });
#else
    (void)who;
    (void)essential;
#endif
}
namespace {
std::mutex g_pause_mutex;
std::condition_variable g_pause_cv;
std::atomic<bool> g_paused{false};
std::chrono::steady_clock::time_point g_paused_at;
}  // namespace
namespace {
std::atomic<uint64_t> g_frames_shown{0};
}
void CountFrameShown() { g_frames_shown.fetch_add(1, std::memory_order_relaxed); }
uint64_t FramesShown() { return g_frames_shown.load(std::memory_order_relaxed); }

void SetPaused(bool paused) {
    {
        std::lock_guard<std::mutex> lk(g_pause_mutex);
        if (g_paused.load() == paused) return;
        g_paused.store(paused);
        if (paused) g_paused_at = std::chrono::steady_clock::now();
    }
    g_pause_cv.notify_all();
    LOGI("platform", "%s", paused ? "paused: the game is held until the app is back in the foreground"
                                  : "resumed");
}
bool IsPaused() { return g_paused.load(std::memory_order_relaxed); }
double WaitWhilePaused(int grace_ms) {
    if (!g_paused.load(std::memory_order_acquire)) return 0;
    const auto start = std::chrono::steady_clock::now();
    std::unique_lock<std::mutex> lk(g_pause_mutex);
    if (!g_paused) return 0;
    if (grace_ms > 0 && start - g_paused_at < std::chrono::milliseconds(grace_ms)) return 0;
    g_pause_cv.wait(lk, [] { return !g_paused.load(); });
    return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
}
void SetCreateUserFile(CreateUserFileFn fn) { g_create.store(fn); }
int CreateUserFile(const char* name, const char* mime_type) {
    CreateUserFileFn fn = g_create.load();
    return fn ? fn(name, mime_type) : -1;
}
namespace {
std::atomic<RequestTextFn> g_request_text{nullptr};
std::mutex g_text_mutex;
bool g_text_ready = false, g_text_ok = false;
std::u16string g_text;
}  // namespace
void SetRequestText(RequestTextFn fn) { g_request_text.store(fn); }
bool RequestText(const char* title, const std::u16string& initial, int max_length) {
    {
        std::lock_guard<std::mutex> lk(g_text_mutex);
        g_text_ready = false;
    }
    RequestTextFn fn = g_request_text.load();
    return fn && fn(title, initial, max_length);
}
void DeliverText(bool ok, const std::u16string& text) {
    std::lock_guard<std::mutex> lk(g_text_mutex);
    g_text_ready = true;
    g_text_ok = ok;
    g_text = text;
}
bool TakeText(bool* ok, std::u16string* text) {
    std::lock_guard<std::mutex> lk(g_text_mutex);
    if (!g_text_ready) return false;
    g_text_ready = false;
    *ok = g_text_ok;
    *text = g_text;
    return true;
}
}  // namespace dsr::platform

namespace dsr::platform {
bool NativeCodeOptimized() {
#ifdef __OPTIMIZE__
    return true;
#else
    return false;
#endif
}
}  // namespace dsr::platform
